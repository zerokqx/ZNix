#!/usr/bin/env bash

# Директория для сохранения
DIR="${ROFI_SCREENSHOT_DIR:-$HOME/Pictures/Screenshots}"
mkdir -p "$DIR"

# Формат даты
DATE_FORMAT="${ROFI_SCREENSHOT_DATE_FORMAT:-+%Y-%m-%d-%H-%M-%S}"

# Файл для сохранения
FILE="$DIR/$(date "$DATE_FORMAT").png"

# Опции меню
OPTIONS="📸 Снимок области в файл
📋 Снимок области в буфер
🖥️ Снимок всего экрана в файл
📋 Снимок всего экрана в буфер
🎥 Запись области (MP4)
🎥 Запись всего экрана (MP4)
⏹️ Остановить запись"

CHOICE=$(echo -e "$OPTIONS" | rofi -dmenu -p "Screenshot/Record")

case "$CHOICE" in
  "📸 Снимок области в файл")
    grim -g "$(slurp)" "$FILE"
    notify-send "Скриншот сохранён" "$FILE"
    ;;
  "📋 Снимок области в буфер")
    grim -g "$(slurp)" - | wl-copy
    notify-send "Скриншот скопирован в буфер"
    ;;
  "🖥️ Снимок всего экрана в файл")
    grim "$FILE"
    notify-send "Скриншот сохранён" "$FILE"
    ;;
  "📋 Снимок всего экрана в буфер")
    grim - | wl-copy
    notify-send "Скриншот скопирован в буфер"
    ;;
  "🎥 Запись области (MP4)")
    wf-recorder -g "$(slurp)" -f "$DIR/$(date "$DATE_FORMAT").mp4" &
    notify-send "Начата запись области"
    ;;
  "🎥 Запись всего экрана (MP4)")
    wf-recorder -f "$DIR/$(date "$DATE_FORMAT").mp4" &
    notify-send "Начата запись экрана"
    ;;
  "⏹️ Остановить запись")
    pkill -INT wf-recorder
    notify-send "Запись остановлена"
    ;;
esac
