import c from "chalk"

console.log(c.blue.bold("Welcome to ZNix configuration"))

console.log(c.green("- Run `mng` command for launch manager"))

