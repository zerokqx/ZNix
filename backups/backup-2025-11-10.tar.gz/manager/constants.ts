export const tmpName = "znix"
export const lastHost = `/tmp/${tmpName}/last`
export const cwdDir = process.cwd()

